﻿namespace TravelAgency.Enums
{
    public enum Commands
    {
        AddAir,
        DeleteAir,
        AddTrain,
        DeleteTrain,
        AddBus,
        DeleteBus,
        FindTickets,
        FindTicketsInInterval
    }
}