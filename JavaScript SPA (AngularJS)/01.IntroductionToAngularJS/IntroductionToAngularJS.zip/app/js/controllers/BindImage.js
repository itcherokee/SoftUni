'use strict';

angular.module('introToAngular')
    .controller('BindImage', [function () {
        this.url = 'http://www.nakov.com/wp-content/uploads/2014/05/SoftUni-Logo.png';
    }]);