'use strict';

angular.module('CtrlAndMarkup', []);
