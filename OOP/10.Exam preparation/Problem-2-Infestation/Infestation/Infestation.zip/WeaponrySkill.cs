﻿namespace Infestation
{
    public class WeaponrySkill : Supplement
    {
    }
}