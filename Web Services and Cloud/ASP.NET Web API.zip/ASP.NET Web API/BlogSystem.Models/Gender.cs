﻿namespace BlogSystem.Models
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
